from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

comp=input("Enter the company name : ")
dic={}
dic["Company"]=comp
print(dic)

for doc in coll.find(dic):
    print(doc)