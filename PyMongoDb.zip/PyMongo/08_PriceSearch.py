from pymongo import MongoClient
client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

pri=int(input("Enter your price range : "))
qr={}
qr["Price"]=pri
print(qr)


for doc in coll.find({"Price":{"$lt":pri}}):
    print("According to your price range we have these mobile phones for you...\n",doc)


