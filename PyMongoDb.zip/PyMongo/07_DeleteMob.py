from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]
co=db["outofstock"]

Id=int(input("Enter the id of the mobile you want to delete  : "))
qr={}
qr["_id"]=Id
print(qr)

for doc in coll.find(qr):
    print(doc)
    co.insert_one(doc)
    coll.delete_one(doc)
    
print("Mobile is out of Stock Now....")
