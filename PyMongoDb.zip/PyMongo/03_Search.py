from pymongo import MongoClient

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

id=int(input("Enter the mobile ID : "))
mob={}
mob["_id"]=id
print(mob)

for doc in coll.find(mob):
    print(doc)

