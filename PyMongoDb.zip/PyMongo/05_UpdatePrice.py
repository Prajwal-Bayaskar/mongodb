from pymongo import MongoClient

Id=int(input("Enter Mobile Id : "))
dic={}
dic["_id"]=Id

print(dic)

Newp=int(input("Enter New price of the mobile : "))
pr={}
pr["Price"]=Newp

print(pr)

upd={"$set":pr}

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]


coll.update_one(dic,upd)
print("New Price Updated Successfully..!!!")