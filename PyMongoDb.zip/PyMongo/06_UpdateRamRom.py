from pymongo import MongoClient


Id=int(input("Enter the ID of the mobile : "))
ram=input("Enter RAM : ")
rom=input("Enter ROM : ")

dic={}
dic["_id"]=Id
dic["RAM"]=ram
dic["ROM"]=rom
print(dic)

nram=input("Enter new RAM :")
nrom=input("Enter new ROM :")
qr={}
qr["RAM"]=nram
qr["ROM"]=nrom
print(qr)

upd={"$set":qr}

client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

coll.update_many(dic,upd)

print("RAM and ROM are updated successfully..")






