from pymongo import MongoClient


id=int(input("Enter Mobile ID : "))
comp=input("Enter Company name : ")
mod=input("Enter Model name : ")
pro=input("Enter Processor name : ")
scsi=(input("Enter ScreenSize : "))
ram=input("Enter RAM : ")
rom=input("Enter ROM : ")
con=input("Enter Connectivity : ")
pri=int(input("Enter Price of the Mobile : "))
rate=float(input("Enter Mobile rating : "))

dic={}
dic["_id"]=id
dic["Company"]=comp
dic["Model"]=mod
dic["Processor"]=pro
dic["Screensize"]=scsi
dic["RAM"]=ram
dic["ROM"]=rom
dic["Connectivity"]=con
dic["Price"]=pri
dic["Rating"]=rate


client=MongoClient("mongodb://localhost:27017")
db=client["shopping"]
coll=db["mobiles"]

coll.insert_one(dic)
print("New Mobile added to the Collection Successfully...")















